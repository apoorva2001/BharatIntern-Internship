
        function convertTemperature() {
            const temperatureInput = document.getElementById("temperature").value;
            const unit = document.getElementById("unit").value;
            let result;

            if (unit === "fahrenheit") {
                result = (temperatureInput * 9/5) + 32;
                document.getElementById("result").textContent = `Converted Temperature: ${result.toFixed(2)} °F`;
            } else if (unit === "celsius") {
                result = (temperatureInput - 32) * 5/9;
                document.getElementById("result").textContent = `Converted Temperature: ${result.toFixed(2)} °C`;
            }
        }
  